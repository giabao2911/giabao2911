<p align="center" width="100%">
    <img width="100%" src="https://user-images.githubusercontent.com/73953379/222469028-8940929c-4dd0-4f38-a718-185d2efd9b32.png">
</p>

Credit for main functions: wodxgod

WORKS ONLY WITH PUBLIC IP

HOWTO 

-- Download PuTTY

-- Open cmd in folder and run 'pip install -r requirements.txt'

-- To add methods make a method.py script in "Commands" then add the command in main script "cnc.py"

-- Connect from putty using telnet/raw

-- For Windows the payload is an executable that can be created using autopytoexe.bat

-- For Linux the payload is a bash file that installs python then runs it as superuser

CHANGELOG

9/28/2022/
- Started idea

9/31/2022/
- Made the code work

- Added methods

10/1/2022/
- Added layer 3 method

- Optimized code

- Organised code

10/2/2022/
- Made code even more optimized

- Added "About" and fixed unknown code errors 

12/13/2022/
- Fixed only one slave connection

- Fixed Layer 4 attacks and removed useless ones

- Removed Layer 3 method

- Optimized code

2/11/2023/
- Fixed half code

- Many bugs

- Needs optimization

2/3/2023/
- Changed name from NixC2 to NebulaC2

- Fixed the whole code

- Less bugs

- Optimized the code

- Added Layer 7

- Added more methods

- Added commands

- Added captcha generator

- Added user registration

- Added admin commands

- Many more!

IDEAS

-- Add ntp amp attack

-- Optimize malicious code  

-- Add ip scanner and exploiter

-- Proxy support

-- Send attacks using api

-- Spoofers

-----------------------------------------------------------

<p align="center" width="100%">
    <img width="100%" src="https://user-images.githubusercontent.com/73953379/222468678-26a46e94-0f1d-49f9-b5e2-6ce5d6dc20cd.png">
</p>

-----------------------------------------------------------

!! FOR EDUCATIONAL PURPOSES ONLY !!

-----------------------------------------------------------

Not responsible for any malicious use of this tool.
